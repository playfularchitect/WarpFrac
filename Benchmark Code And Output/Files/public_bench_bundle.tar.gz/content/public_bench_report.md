# INT8→INT32 Exact GEMM — Public Benchmark

_Generated: 2025-11-07T10:02:29+00:00_

## Headline (Macro Arena)
- **Throughput:** **300.13 T-ops/s**  
- **Config:** M=N=K=5120, streams=32, nodes=64, tileK=1280 (panels=4), epochs=2  
- **cuBLASLt algo:** index=0  workspace=1024 MB  
- **Exactness:** micro validator **PASS** vs CPU int32; GMP sampled witnesses printed.

## Micro Head-to-Head vs GMP (Exact Integers)
| Shape | Shift | GPU ms | GPU T-ops/s | GMP ms | GMP G-ops/s | Speedup | Exact |
|---:|---:|---:|---:|---:|---:|---:|:--:|
| 128³ | 8 | 4.944 | 0.001000 | 42.306 | 0.099142 | 8.56× | PASS |
| 192³ | 8 | 5.015 | 0.003000 | 140.976 | 0.100412 | 28.11× | PASS |
| 256³ | 8 | 5.063 | 0.007000 | 335.310 | 0.100070 | 66.23× | PASS |

### Dyadic `mpq` samples

**Shape 128×128×128**

```
C[0,0] int32=-8188   C_real=-2047/64
C[21,42] int32=31289   C_real=31289/256
C[42,84] int32=-64593   C_real=-64593/256
C[63,126] int32=41221   C_real=41221/256
C[85,40] int32=-62714   C_real=-31357/128
C[106,82] int32=45047   C_real=45047/256
```

**Shape 192×192×192**

```
C[0,0] int32=-44682   C_real=-22341/128
C[32,0] int32=45766   C_real=22883/128
C[64,0] int32=-20511   C_real=-20511/256
C[96,0] int32=-29605   C_real=-29605/256
C[128,0] int32=91352   C_real=11419/32
C[160,0] int32=15501   C_real=15501/256
```

**Shape 256×256×256**

```
C[0,0] int32=-73289   C_real=-73289/256
C[42,170] int32=43845   C_real=43845/256
C[85,84] int32=127827   C_real=127827/256
C[127,254] int32=159434   C_real=79717/128
C[170,168] int32=-70952   C_real=-8869/32
C[213,82] int32=-5279   C_real=-5279/256
```

## Micro Throughput (Amortized — CUDA Graph + Reps)
`256³`, reps=500 (warmup=5):  
- **GPU:** elapsed=8.280 ms, avg/ GEMM=0.016560 ms, **2.026 T-ops/s**  
- **GMP (one GEMM):** 312.940 ms, 0.107223 G-ops/s  
- **Speedup:** 18897.23× per-GEMM vs GMP  

---
## Provenance & Environment
- Timestamp (UTC): `2025-11-07T10:02:31+00:00`
- GPU: `NVIDIA A100-SXM4-40GB`  |  SMs: `108`  |  Memory: `40506 MB`
- Recommended NVCC arch: ``-arch=sm_80``
- CUDA Runtime: `12.5.0 (12050)`  |  Driver: `12.4.0 (12040)`
- cuBLAS version: `120503`  |  cuBLASLt version: `120503`
- Ops definition: `logical ops/s = 2 * M * N * K` per GEMM.
- Arithmetic: INT8×INT8 → INT32 accumulate, exact; real-valued interpretation via dyadic `2^-(fracA+fracB)`.
